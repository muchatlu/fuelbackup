puppet-zabbix
=============

intended to work with fuel-library
