require 'spec_helper'

describe 'vmware_index' do
end
