## 2015-01-07 - Release 1.2.4

- Fix unquoted strings in cases

## 2015-01-05 - Release 1.2.3

- Fix .travis.yml

## 2014-12-18 - Release 1.2.2

- Fix LICENSE file to match metadata.json
- Remove puppet_version from metadata.json

## 2014-12-18 - Release 1.2.1

- Various improvements in unit tests

## 2014-12-09 - Release 1.2.0

- Fix metadata.json warnings
- Add future parser tests
- Fix future parser errors

## 2014-11-25 - Release 1.1.0

- Corrected and added new features for openssl::export::pkcs12

## 2014-11-17 - Release 1.0.1

- Lint metadata.json

## 2014-10-20 - Release 1.0.0

- Setup automatic Forge releases

## 2014-07-02 - Release 0.3.0

- Add more tests
